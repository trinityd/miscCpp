#include "RegistrationBook.h"
#include <string>
using std::string;
using std::cout;

int main() {
  RegistrationBook registration_book;
  registration_book.run();

  return 0;
}
